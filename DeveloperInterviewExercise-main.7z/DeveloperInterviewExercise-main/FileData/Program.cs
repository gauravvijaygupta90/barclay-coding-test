﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {

        public static void Main(string[] args)
        {
            ITaskManager taskManager = new TaskManager();
            Console.Write("The First argument:- ");
            string firstArgu = Convert.ToString(Console.ReadLine());
            if (firstArgu == "-v")
            {
                Console.Write("The Second argument:- ");
                string seccondArgu = Convert.ToString(Console.ReadLine());

                Console.WriteLine("Task 1 output:- \n");
                taskManager.Task1(firstArgu, seccondArgu);

                Console.WriteLine("\n");
                Console.WriteLine("Task 2 output:- \n");
                taskManager.Task2(firstArgu);
            }
            else
            {
                Console.WriteLine("Task 2 output:- \n");
                taskManager.Task2(firstArgu);
            }
            Console.Read();
        }

        
    }
}
