﻿namespace FileData
{
    public interface ITaskManager
    {
        void Task1(string firstArgu, string seccondArgu);
        void Task2(string firstArgu);
    }
}
