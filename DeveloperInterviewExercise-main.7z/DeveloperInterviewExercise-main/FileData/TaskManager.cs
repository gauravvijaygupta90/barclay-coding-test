﻿using System;
using System.Diagnostics;
using ThirdPartyTools;

namespace FileData
{
    public class TaskManager : ITaskManager
    {
        public void Task1(string firstArgu, string seccondArgu)
        {
            try
            {
                FileDetails objFile = new FileDetails();
                if (firstArgu == "-v")
                {
                    string Version = objFile.Version(seccondArgu);
                    Console.WriteLine(Version);
                }
            }
            catch (Exception ex)
            {

                StackFrame callStack = new StackFrame(1, true);
                Console.Write("Error in Line(" + callStack.GetFileLineNumber() + ") -" + ex.Message);
            }
        }
        public void Task2(string firstArgu)
        {
            try
            {
                FileDetails objFile = new FileDetails();
                if (firstArgu == "-v" || firstArgu == "--v" || firstArgu == "/v" || firstArgu == "--version")
                {
                    string Version = objFile.Version(firstArgu);
                    Console.WriteLine(Version);
                }
                else if (firstArgu == "-s" || firstArgu == "--s" || firstArgu == "/s" || firstArgu == "--size")
                {
                    int size = objFile.Size(firstArgu);
                    Console.WriteLine(size);
                }
            }
            catch (Exception ex)
            {
                StackFrame callStack = new StackFrame(1, true);
                Console.Write("Error in Line(" + callStack.GetFileLineNumber() + ") -" + ex.Message);
            }

        }
    }
}
